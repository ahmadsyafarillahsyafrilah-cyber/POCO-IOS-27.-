# POCO IOS 27 — proyek sumber

Proyek Android native Kotlin menggunakan CameraX. Ini adalah kode sumber, bukan APK yang sudah jadi dan belum dijamin berhasil dibangun atau diuji di perangkat.

## Build APK lewat GitHub Actions dari HP
1. Ekstrak ZIP ini ke folder di HP.
2. Di GitHub, buat repository baru bernama `POCO-IOS-27`, pilih **Public** jika ingin memakai GitHub Actions gratis dengan langkah paling sederhana, dan centang opsi README hanya jika tidak mengunggah file yang bertabrakan.
3. Buka repository → **Add file** → **Upload files**. Unggah semua file dan folder dari hasil ekstrak, termasuk folder tersembunyi `.github/workflows/android.yml`. Pastikan `settings.gradle.kts` berada di root repository, bukan di subfolder tambahan.
4. Commit perubahan ke branch `main`.
5. Buka tab **Actions**. Pilih workflow **Build POCO IOS 27 APK** lalu **Run workflow** jika tersedia. Push ke `main` juga otomatis memicu build.
6. Buka proses workflow yang paling baru. Jika tanda hijau berhasil, buka bagian **Artifacts** dan unduh `POCO-IOS-27-debug-apk`.
7. Ekstrak ZIP artifact yang diunduh; di dalamnya ada `app-debug.apk`. Ketuk file APK untuk memasang. Android mungkin meminta izin memasang aplikasi dari browser/File Manager; aktifkan hanya untuk sumber yang kamu percaya, lalu nonaktifkan lagi setelah selesai.

Catatan: Pada GitHub mobile, mengunggah folder sekaligus mungkin sulit. Jika folder `.github` tidak bisa diunggah, buat folder dan file workflow lewat editor GitHub secara manual. Jangan unggah token, kata sandi, atau data pribadi.

Fitur fisik ultrawide 0.6× dan perpindahan lensa saat video bergantung pada dukungan perangkat/CameraX dan belum diverifikasi. APK hasil debug bukan aplikasi terverifikasi atau rilis Play Store.
