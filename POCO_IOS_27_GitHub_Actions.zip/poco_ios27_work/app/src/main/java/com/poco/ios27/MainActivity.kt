package com.poco.ios27

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.poco.ios27.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var isVideoMode = false
    private var usingFrontCamera = false
    private var flashEnabled = false

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCameraPermission()) startCamera()
            else Toast.makeText(this, "Izin kamera diperlukan", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.zoom06.setOnClickListener { setZoom(0.6f) }
        binding.zoom1.setOnClickListener { setZoom(1f) }
        binding.zoom2.setOnClickListener { setZoom(2f) }
        binding.photoMode.setOnClickListener { setVideoMode(false) }
        binding.videoMode.setOnClickListener { setVideoMode(true) }
        binding.portraitMode.setOnClickListener {
            Toast.makeText(this, "Mode Potret khusus belum tersedia", Toast.LENGTH_SHORT).show()
        }
        binding.shutterButton.setOnClickListener {
            if (isVideoMode) toggleVideoRecording() else takePhoto()
        }
        binding.switchCameraButton.setOnClickListener {
            if (recording != null) {
                Toast.makeText(this, "Hentikan rekaman sebelum ganti kamera depan/belakang", Toast.LENGTH_SHORT).show()
            } else {
                usingFrontCamera = !usingFrontCamera
                startCamera()
            }
        }
        binding.flashButton.setOnClickListener {
            flashEnabled = !flashEnabled
            camera?.cameraControl?.enableTorch(flashEnabled && !usingFrontCamera)
            binding.flashButton.alpha = if (flashEnabled) 1f else 0.65f
        }
        binding.galleryButton.setOnClickListener {
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            }
            try { startActivity(intent) } catch (_: Exception) {
                Toast.makeText(this, "Buka Galeri dari layar utama", Toast.LENGTH_SHORT).show()
            }
        }

        if (hasCameraPermission()) startCamera() else permissionsLauncher.launch(
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        )
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val selector = if (usingFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val preview = Preview.Builder().build().also { it.surfaceProvider = binding.previewView.surfaceProvider }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture, videoCapture)
                camera?.cameraInfo?.zoomState?.observe(this) { state ->
                    if (state != null) binding.statusText.text = "Kamera aktif • ${String.format(Locale.US, "%.1f", state.zoomRatio)}×"
                }
                binding.statusText.text = "Kamera aktif"
            } catch (e: Exception) {
                binding.statusText.text = "Kamera gagal dibuka"
                Toast.makeText(this, "Kamera gagal: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setZoom(requested: Float) {
        val cam = camera ?: return
        val state = cam.cameraInfo.zoomState.value ?: return
        val target = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        cam.cameraControl.setZoomRatio(target)
        binding.zoom06.setTextColor(if (requested == 0.6f) 0xFFFFD45C.toInt() else 0xFFFFFFFF.toInt())
        binding.zoom1.setTextColor(if (requested == 1f) 0xFFFFD45C.toInt() else 0xFFFFFFFF.toInt())
        binding.zoom2.setTextColor(if (requested == 2f) 0xFFFFD45C.toInt() else 0xFFFFFFFF.toInt())
        binding.statusText.text = if (target != requested) "Zoom minimum perangkat: ${target}×" else "Zoom ${target}×"
    }

    private fun setVideoMode(video: Boolean) {
        isVideoMode = video
        binding.photoMode.setTextColor(if (!video) 0xFFFFD45C.toInt() else 0xFF888888.toInt())
        binding.videoMode.setTextColor(if (video) 0xFFFFD45C.toInt() else 0xFF888888.toInt())
        binding.statusText.text = if (video) "VIDEO • tekan tombol untuk merekam" else "FOTO"
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "POCO_IOS27_$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/POCO IOS 27")
        }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                Toast.makeText(this@MainActivity, "Foto tersimpan di Galeri", Toast.LENGTH_SHORT).show()
            }
            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(this@MainActivity, "Gagal mengambil foto: ${exception.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun toggleVideoRecording() {
        if (recording != null) {
            recording?.stop()
            binding.statusText.text = "Menyimpan video..."
            return
        }
        val capture = videoCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "POCO_IOS27_$stamp.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/POCO IOS 27")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> binding.statusText.text = "● MEREKAM"
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    binding.statusText.text = if (event.hasError()) "Rekaman gagal" else "Video tersimpan di Galeri"
                    Toast.makeText(this, binding.statusText.text, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        recording?.stop()
        super.onDestroy()
    }
}
